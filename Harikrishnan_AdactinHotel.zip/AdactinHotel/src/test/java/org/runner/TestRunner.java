package org.runner;

import org.base.TC01_AdactinLoginPage;
import org.base.TC02_AdactinSearchHotelPage;
import org.base.TC03_AdactinSelectHotel;
import org.base.TC04_AdactinBookHotel;
import org.base.TC05_AdactinBookingConfirmation;
import org.base.TC06_AdactinBookedItinerary;
import org.base.TC07_AdactinLoginAgain;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({
	
	TC01_AdactinLoginPage.class,
	TC02_AdactinSearchHotelPage.class,
	TC03_AdactinSelectHotel.class,
	TC04_AdactinBookHotel.class,
	TC05_AdactinBookingConfirmation.class,
	TC06_AdactinBookedItinerary.class,
	TC07_AdactinLoginAgain.class
})
public class TestRunner {

}

